# Session07 - Multithreaded Fractal Generator

In this session, we further extend upon last week's generator to add multithreading.

# Recompiling

To recompile, first install the development X11 libraries via

```
sudo apt-get install libx11-dev
```

Then, compile with `make`. If you are following with session06, then there should be nothing new to install.

# Running

The arguments are almost the same as session06, with the exception of another parameter to specify how many threads should be used. Because of how the app is programmed, you must enter a number of threads that divides into the width of the frame. For instance, if we have a window width of 600, we can choose any number of threads that divides into 600. Arguments are as follows:

```
./fractal width height max_iterations num_threads c1 c2 min_x min_y max_x max_y
```

